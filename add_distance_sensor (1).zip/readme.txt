demo.c   : delete

demo.cpp : copy in src directory

vl*      : copy in src directory

makefile : overwrite in top directory


